</header>

<div class="content-wrapper container">
	<div class="page-content">
		<section class="row">
			<div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4># Dashboard</h4>
                    </div>
                    <div class="card-body">
                        <div style="width:100%;display:flex;justify-content:center;align-items:center;flex-direction:column;">
							<img src="<?=base_url('logo/logo.png');?>" alt="Logo Bosami Batik" style="width:250px;">
							<p style="color:#6e5a42;font-size:20px;margin-top:10px;">Selamat Datang di Aplikasi Bosami Batik</p>
						</div>
                    </div>
                </div>
            </div>
		</section>

	</div>

</div>

            