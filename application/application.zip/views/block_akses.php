</header>

<div class="content-wrapper container">
	<div class="page-content">
		<section class="row">
			<div class="col-12">
                <div class="card">
                    <div class="card-header" style="width:100%;display:flex;justify-content:space-between;align-items:center;">
                        <h4>AKSES DI BLOKIR</h4>
                    </div>
                    <div class="card-body" style="color:red;">
                        Maaf, Anda tidak di bolehkan mengakses halaman ini..!!!
                    </div>
                </div>
            </div>
		</section>
                            
	</div>

</div>

            