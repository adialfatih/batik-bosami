<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>404 HALAMAN TIDAK DITEMUKAN</title>
</head>
<style>
	body {
		width: 100%;
		header : 100vh;
	}
	.container {
		width: 100%;
		header: 100vh;
		display:flex;
		flex-direction:column;
		justify-content:center;
		align-items:center;
		gap: 50px;
	}
</style>
<body>
	<div class="container">
		<img src="<?=base_url('logo/logo.png');?>" alt="Logo Damay Raya">
	</div>
</body>
</html>